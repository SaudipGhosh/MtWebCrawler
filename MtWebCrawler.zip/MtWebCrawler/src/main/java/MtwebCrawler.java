import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class MtwebCrawler {

    public static void main(String[] args) {
        ArrayList<WebCrawler> bot = new ArrayList<>();
        bot.add(new WebCrawler("https://www.honda2wheelersindia.com/campaign-shine-BS-VI?utm_source=smart&utm_medium=cpc&utm_campaign=shine_smart&utm_term=paid&gclid=Cj0KCQjwu-KiBhCsARIsAPztUF0MsiCawWg04f2OXx1QnBOX0FAJ3J8jc5RwTPzwGxhnvah_UvQggLIaAp4nEALw_wcB"));
        //bot.add(new WebCrawler("https://www.baeldung.com/java-concurrent-hashset-concurrenthashmap"));

        for(WebCrawler u:bot)
        {
            try{
            u.getThread().join();}catch(InterruptedException e)
            {
                e.printStackTrace();
            }

        }
        WebCrawler wc= new WebCrawler();
        ArrayList<String> visitedUrl= wc.visitedUrl;

        try{
            FileWriter fileWriter = new FileWriter("E:\\url.txt");
            for(String url :visitedUrl)
            {
                fileWriter.write(url);
            }

        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
